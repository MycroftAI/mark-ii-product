#!/usr/bin/env python3
import dataclasses
import io
import logging
import threading
import time
import typing
from dataclasses import dataclass, field
from pathlib import Path
from queue import Queue

import gruut
import numpy as np
import onnxruntime
import phonemes2ids
from gruut.const import LookupPhonemes, WordRole
from gruut_ipa import IPA, Phoneme, Phonemes, guess_phonemes

from .config import TrainingConfig
from .utils import audio_float_to_int16
from .wavfile import write as write_wav

_DIR = Path(__file__).parent

_LOGGER = logging.getLogger(__name__)

# -----------------------------------------------------------------------------


@dataclass
class Result:
    """Result from calling Mimic 3"""

    text: str = ""
    sentence_words: typing.List[typing.List[str]] = field(default_factory=list)
    sentence_phonemes: typing.List[typing.List[str]] = field(default_factory=list)
    sentence_phoneme_ids: typing.List[typing.List[int]] = field(default_factory=list)
    wav_bytes: bytes = field(default_factory=bytes)


@dataclass
class AddLexiconMessage:
    lexicon_file: typing.Iterable[str]


@dataclass
class TextToSpeechMessage:
    text: str
    speaker_id: typing.Optional[int] = None
    length_scale: typing.Optional[float] = None
    noise_scale: typing.Optional[float] = None
    noise_w: typing.Optional[float] = None
    ssml: bool = False
    text_language: typing.Optional[str] = None


# -----------------------------------------------------------------------------


class Mimic3:
    """Convert text to speech using Mimic 3"""

    def __init__(
        self,
        model_dir: typing.Union[str, Path],
        lang: typing.Optional[str] = None,
        speaker_id: typing.Optional[int] = None,
        length_scale: typing.Optional[float] = None,
        noise_scale: typing.Optional[float] = None,
        noise_w: typing.Optional[float] = None,
    ):
        self.model_dir = Path(model_dir)
        self.speaker_id = speaker_id
        self.lang = lang

        self.length_scale = length_scale
        self.noise_scale = noise_scale
        self.noise_w = noise_w

        # Mapping from phonemes to ids
        self._phoneme_to_id: typing.Optional[typing.Dict[str, int]] = None
        self._voice_phonemes: typing.Optional[Phonemes] = None

        # Mapping from phoneme to one or more phonemes
        self._phoneme_map: typing.Optional[typing.Dict[str, typing.List[str]]] = None

        self._onnx_model: typing.Optional[onnxruntime.InferenceSession] = None

        self._config: typing.Optional[TrainingConfig] = None

        self._text_processor: typing.Optional[gruut.TextProcessor] = None

        # Need to do TTS stuff in a separate thread because of sqlite (used by gruut)
        self._request_queue: "Queue[typing.Any]" = Queue()
        self._result_queue: "Queue[typing.Any]" = Queue(maxsize=1)
        self._thread = threading.Thread(target=self._thread_proc, daemon=True)
        self._thread.start()

    def start(self):
        self.stop()

        self._thread = threading.Thread(target=self._thread_proc, daemon=True)
        self._thread.start()

    def stop(self):
        if self._thread is not None:
            self._request_queue.put(None)
            self._thread.join()
            self._thread = None

        # Drain queues
        while not self._request_queue.empty():
            self._request_queue.get()

        while not self._result_queue.empty():
            self._result_queue.get()

    def _thread_proc(self):
        try:
            self._load_model()
            self._load_text_processor()

            while True:
                message = self._request_queue.get()
                if message is None:
                    break

                if isinstance(message, AddLexiconMessage):
                    self._add_lexicon(message.lexicon_file)
                elif isinstance(message, TextToSpeechMessage):
                    result = self._text_to_speech(**dataclasses.asdict(message))
                    self._result_queue.put(result)

        except Exception:
            _LOGGER.exception("_thread_proc")

    def _load_model(self):
        """Load model configuration and generator"""

        if self._config is None:
            config_path = self.model_dir / "config.json"
            _LOGGER.debug("Loading model config from %s", config_path)

            with open(config_path, "r", encoding="utf-8") as config_file:
                self._config = TrainingConfig.load(config_file)

        self.lang = self.lang or self._config.text_language or "en_US"

        if self._phoneme_to_id is None:
            # phoneme -> id
            phoneme_ids_path = self.model_dir / "phonemes.txt"
            _LOGGER.debug("Loading model phonemes from %s", phoneme_ids_path)
            with open(phoneme_ids_path, "r", encoding="utf-8") as ids_file:
                self._phoneme_to_id = phonemes2ids.load_phoneme_ids(ids_file)

            valid_phonemes = []
            for phoneme_str in self._phoneme_to_id:
                maybe_phoneme = Phoneme(phoneme_str)
                if any(
                    [
                        maybe_phoneme.vowel,
                        maybe_phoneme.consonant,
                        maybe_phoneme.dipthong,
                        maybe_phoneme.schwa,
                    ]
                ):
                    valid_phonemes.append(maybe_phoneme)

            self._voice_phonemes = Phonemes(phonemes=valid_phonemes)

        if self._phoneme_map is None:
            # phoneme -> phoneme, phoneme, ...
            phoneme_map_path = self.model_dir / "phoneme_map.txt"
            if phoneme_map_path.is_file():
                _LOGGER.debug("Loading phoneme map from %s", phoneme_map_path)
                with open(phoneme_map_path, "r", encoding="utf-8") as map_file:
                    self._phoneme_map = phonemes2ids.utils.load_phoneme_map(map_file)

        if self._onnx_model is None:
            generator_path = self.model_dir / "generator.onnx"
            _LOGGER.debug("Loading model from %s", generator_path)

            sess_options = onnxruntime.SessionOptions()
            sess_options.enable_cpu_mem_arena = False
            sess_options.enable_mem_pattern = False
            sess_options.enable_mem_reuse = False

            self._onnx_model = onnxruntime.InferenceSession(
                str(generator_path), sess_options=sess_options
            )

    def _load_text_processor(self):
        if self._text_processor is None:
            self._text_processor = gruut.TextProcessor(default_lang=self.lang)

    def add_lexicon(self, lexicon_file: typing.Iterable[str]):
        """Load a custom pronunciation lexicon from a file.

        Format is:
        <word> <role> <phoneme> <phoneme> ...

        Role can be things like "gruut:VB" or "gruut:NN".
        Use "_" for the default role (any part of speech).
        """
        self._request_queue.put(AddLexiconMessage(lexicon_file=list(lexicon_file)))

    def _add_lexicon(self, lexicon_file: typing.Iterable[str]):
        self._load_text_processor()
        assert self._text_processor is not None

        # word -> role -> [phoneme, phoneme, ...]
        lexicon: typing.Dict[str, typing.Dict[str, typing.List[str]]] = {}

        for line in lexicon_file:
            line = line.strip()
            if not line:
                continue

            word, role, *phonemes = line.split()
            if (not word) or (not phonemes):
                _LOGGER.warning("Empty word or pronunciation in lexicon: %s", line)
                continue

            if role == "_":
                role = WordRole.DEFAULT

            word_roles = lexicon.get(word)
            if word_roles is None:
                word_roles = {}
                lexicon[word] = word_roles

            word_roles[role] = phonemes

        if lexicon:

            # Wrap the "lookup_phonemes" method in the gruut text processor.
            # Our lexicon will be consulted first.
            settings = self._text_processor.get_settings()
            base_lookup = settings.lookup_phonemes

            def lookup_phonemes(word: str, role: typing.Optional[str] = None, **kwargs):
                word_roles = lexicon.get(word)

                if not word_roles:
                    # Try lower case
                    word_roles = lexicon.get(word.lower())

                if word_roles:
                    if role is None:
                        role = WordRole.DEFAULT

                    phonemes = word_roles.get(role)

                    if (phonemes is None) and (role != WordRole.DEFAULT):
                        phonemes = word_roles.get(WordRole.DEFAULT)

                    if phonemes:
                        return phonemes

                if base_lookup is not None:
                    return base_lookup(word, role, **kwargs)

                return None

            settings.lookup_phonemes = typing.cast(LookupPhonemes, lookup_phonemes)
            _LOGGER.debug("Added custom pronunciations for %s word(s)", len(lexicon))

    def text_to_speech(
        self,
        text: str,
        speaker_id: typing.Optional[int] = None,
        length_scale: typing.Optional[float] = None,
        noise_scale: typing.Optional[float] = None,
        noise_w: typing.Optional[float] = None,
        ssml: bool = False,
        text_language: typing.Optional[str] = None,
    ) -> Result:
        self._request_queue.put(
            TextToSpeechMessage(
                text=text,
                speaker_id=speaker_id,
                length_scale=length_scale,
                noise_scale=noise_scale,
                noise_w=noise_w,
                ssml=ssml,
                text_language=text_language,
            )
        )

        result = typing.cast(Result, self._result_queue.get())

        return result

    def _text_to_speech(
        self,
        text: str,
        speaker_id: typing.Optional[int] = None,
        length_scale: typing.Optional[float] = None,
        noise_scale: typing.Optional[float] = None,
        noise_w: typing.Optional[float] = None,
        ssml: bool = False,
        text_language: typing.Optional[str] = None,
    ) -> Result:
        """Speak text and return WAV audio as bytes"""
        text_language = text_language or self.lang
        assert self._text_processor is not None

        # Ensure model is loaded
        assert self.lang is not None
        assert self._config is not None
        assert self._phoneme_to_id is not None
        assert self._onnx_model is not None

        # Resolve settings
        if speaker_id is None:
            speaker_id = self.speaker_id or 0

        length_scale = next(
            v
            for v in (
                length_scale,
                self.length_scale,
                self._config.inference.length_scale,
                1.0,
            )
            if v is not None
        )

        noise_scale = next(
            v
            for v in (
                noise_scale,
                self.noise_scale,
                self._config.inference.noise_scale,
                0.667,
            )
            if v is not None
        )

        noise_w = next(
            v
            for v in (noise_w, self.noise_w, self._config.inference.noise_w, 0.8)
            if v is not None
        )

        _LOGGER.info("TTS settings: %s %s %s", length_scale, noise_scale, noise_w)

        # Process text into sentences
        result = Result(text=text)
        audio_arrays: typing.List[np.ndarray] = []

        graph, root = self._text_processor.process(text, lang=text_language, ssml=ssml)
        sentences = list(self._text_processor.sentences(graph, root))

        for sentence in sentences:
            result.sentence_words.append([w.text for w in sentence])

            if text_language == self.lang:
                sent_phonemes = [w.phonemes for w in sentence if w.phonemes]
            else:
                # Convert phonemes to ids to target language
                other_sent_phonemes = [w.phonemes for w in sentence if w.phonemes]
                _LOGGER.debug(other_sent_phonemes)

                sent_phonemes = []
                for other_word_p in other_sent_phonemes:
                    word_p = []
                    for other_p in other_word_p:
                        if IPA.is_break(other_p):
                            # Keep breaks
                            word_p.append(other_p)
                            continue

                        original_p = other_p
                        while other_p and IPA.is_stress(other_p[0]):
                            # _stress = other_p[0]
                            other_p = other_p[1:]

                        if not other_p:
                            continue

                        if other_p in self._phoneme_to_id:
                            word_p.append(original_p)
                            continue

                        assert self._voice_phonemes is not None
                        guessed = guess_phonemes(
                            other_p, to_phonemes=self._voice_phonemes
                        )
                        if guessed.phonemes:
                            word_p.extend([p.text for p in guessed.phonemes])

                    if word_p:
                        sent_phonemes.append(word_p)

            result.sentence_phonemes.append(sent_phonemes)

            sent_phoneme_ids = phonemes2ids.phonemes2ids(
                word_phonemes=sent_phonemes,
                phoneme_to_id=self._phoneme_to_id,
                pad=self._config.phonemes.pad,
                bos=self._config.phonemes.bos,
                eos=self._config.phonemes.eos,
                auto_bos_eos=self._config.phonemes.auto_bos_eos,
                blank=self._config.phonemes.blank,
                blank_word=self._config.phonemes.blank_word,
                blank_between=self._config.phonemes.blank_between,
                blank_at_start=self._config.phonemes.blank_at_start,
                blank_at_end=self._config.phonemes.blank_at_end,
                simple_punctuation=self._config.phonemes.simple_punctuation,
                punctuation_map=self._config.phonemes.punctuation_map,
                separate=self._config.phonemes.separate,
                separate_graphemes=self._config.phonemes.separate_graphemes,
                separate_tones=self._config.phonemes.separate_tones,
                tone_before=self._config.phonemes.tone_before,
                phoneme_map=self._phoneme_map or self._config.phonemes.phoneme_map,
                fail_on_missing=False,
            )

            result.sentence_phoneme_ids.append(sent_phonemes)

            _LOGGER.debug("%s %s %s", sentence.text, sent_phonemes, sent_phoneme_ids)

            # Create model inputs
            text_array = np.expand_dims(np.array(sent_phoneme_ids, dtype=np.int64), 0)
            text_lengths_array = np.array([text_array.shape[1]], dtype=np.int64)
            scales_array = np.array(
                [noise_scale, length_scale, noise_w], dtype=np.float32
            )

            inputs = {
                "input": text_array,
                "input_lengths": text_lengths_array,
                "scales": scales_array,
            }

            if self._config.is_multispeaker:
                speaker_id_array = np.array([speaker_id], dtype=np.int64)
                inputs["sid"] = speaker_id_array

            # Infer audio from phonemes
            start_time = time.perf_counter()
            audio = self._onnx_model.run(None, inputs)[0].squeeze()
            audio = audio_float_to_int16(audio)
            end_time = time.perf_counter()

            # Compute real-time factor
            audio_duration_sec = audio.shape[-1] / self._config.audio.sample_rate
            infer_sec = end_time - start_time
            real_time_factor = (
                infer_sec / audio_duration_sec if audio_duration_sec > 0 else 0.0
            )

            _LOGGER.debug("RTF: %s", real_time_factor)

            audio_arrays.append(audio)

        # Write to WAV and return bytes
        with io.BytesIO() as wav_file:
            write_wav(
                wav_file, self._config.audio.sample_rate, np.concatenate(audio_arrays),
            )

            result.wav_bytes = wav_file.getvalue()

        return result
