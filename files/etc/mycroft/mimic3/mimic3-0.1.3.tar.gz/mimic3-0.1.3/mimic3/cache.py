# Copyright 2022 Mycroft AI Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import argparse
import hashlib
import itertools
import re
import typing
from pathlib import Path

from mimic3.plugin import Mimic3TTSPlugin


def main():
    """Generate WAV cache for dialog/value utterances"""
    parser = argparse.ArgumentParser(prog="mimic3.cache")
    parser.add_argument(
        "--model-dir",
        required=True,
        help="Directory with voice model and config files",
    )
    parser.add_argument(
        "--dialog",
        "-d",
        nargs="+",
        action="append",
        default=[],
        help="Path(s) to .dialog file(s)",
    )
    parser.add_argument(
        "--values",
        "-v",
        nargs="+",
        action="append",
        default=[],
        help="Path(s) to .values file(s)",
    )
    parser.add_argument(
        "--output-dir", "-o", required=True, help="Path to output directory"
    )
    args = parser.parse_args()

    plugin = Mimic3TTSPlugin(lang="en_US", config={"model_directory": args.model_dir})

    args.output_dir = Path(args.output_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    # Value files contain key,value pairs, one per line.
    # The value is synthesized here as the utterance.
    for value_path in itertools.chain.from_iterable(args.values):
        print(value_path)

        with open(value_path, "r", encoding="utf-8") as value_file:
            for line in value_file:
                line = line.strip()
                if "," not in line:
                    continue

                _, utterance = line.split(",", maxsplit=1)
                for text_chunk in split_utterance(utterance):
                    text_to_wav(text_chunk, plugin, args.output_dir)

        print("")

    # Dialog files contain an utterance per line.
    # Utterances may contain one or more {entities}, which are skipped here.
    for dialog_path in itertools.chain.from_iterable(args.dialog):
        print(dialog_path)

        with open(dialog_path, "r", encoding="utf-8") as dialog_file:
            for line in dialog_file:
                line = line.strip()
                if not line:
                    continue

                for text_chunk in split_utterance(line):
                    if "{" in text_chunk:
                        # Skip entities
                        continue

                    text_to_wav(text_chunk, plugin, args.output_dir)

        print("")


# -----------------------------------------------------------------------------


def text_to_wav(text_chunk: str, plugin: Mimic3TTSPlugin, output_dir: Path):
    """Use Mimic 3 plugin to synthesize WAV from text"""
    chunk_hash = hash_chunk(text_chunk)
    wav_path = output_dir / f"{chunk_hash}.wav"
    plugin.get_tts(text_chunk, wav_path)

    print(text_chunk, wav_path)


# -----------------------------------------------------------------------------

# Abraham Lincoln was an American lawyer and statesman who served as the 16th
# president of the United States from 1861 until his assassination in 1865.
#
# f9a317d74b220224ed36330bc619c91c


def split_utterance(utterance: str) -> typing.List[str]:
    """Split an utterance into chunks like Mycroft"""
    return re.split(r"(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\;|\?)\s", utterance)


def hash_chunk(text_chunk: str) -> str:
    """Convert text chunk into hash code like Mycroft"""
    encoded_chunk = text_chunk.encode("utf-8", "ignore")
    return hashlib.md5(encoded_chunk).hexdigest()


# -----------------------------------------------------------------------------

if __name__ == "__main__":
    main()
