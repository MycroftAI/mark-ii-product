# Copyright 2022 Mycroft AI Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import logging
import re
import typing
from pathlib import Path

try:
    from mycroft.messagebus.message import Message
    from mycroft.tts import TTS, TTSValidator
    from mycroft.tts.cache import AudioFile
    from mycroft.util.log import LOG
except ImportError:
    # Dummy classes for use outside of Mycroft
    class DummyMessage:
        def __init__(self, msg_type, data=None, context=None):
            self.msg_type = msg_type
            self.data = data or {}
            self.context = context or {}

    class DummyCache:
        def __init__(self):
            self.cached_sentences: typing.Dict[str, typing.Any] = {}

        def clear(self):
            pass

    class DummyTTS:
        def __init__(
            self,
            lang,
            config,
            validator,
            audio_ext="wav",
            phonetic_spelling=True,
            ssml_tags=None,
        ):
            self.lang = lang
            self.config = config
            self.validator = validator
            self.cache = DummyCache()

    class DummyTTSValidator:
        def __init__(self, tts):
            self.tts = tts

    class DummyAudioFile:
        def __init__(self, cache_dir: Path, sentence_hash: str, file_type: str):
            self.name = f"{sentence_hash}.{file_type}"
            self.path = cache_dir.joinpath(self.name)

    Message = DummyMessage
    TTS = DummyTTS
    TTSValidator = DummyTTSValidator
    AudioFile = DummyAudioFile
    LOG = logging.getLogger("mimic3")


from mimic3 import Mimic3


class Mimic3TTSPlugin(TTS):
    """Mycroft interface to Mimic3."""

    def __init__(self, lang, config):
        self.lang = lang

        model_dir: str = config.get("model_directory", "")
        assert model_dir, "model_directory is required"

        self.model_dir = Path(model_dir)
        self.model: typing.Optional[Mimic3] = None
        self.voice_name: typing.Optional[str] = None

        voice: typing.Optional[str] = config.get("voice")

        super().__init__(lang, config, Mimic3Validator(self), "wav")

        # TODO: Check against model language
        self._change_voice(voice)

        preloaded_cache = config.get("preloaded_cache")
        if preloaded_cache:
            self.persistent_cache_dir = Path(preloaded_cache)
            self.persistent_cache_dir.mkdir(parents=True, exist_ok=True)
            self._load_existing_audio_files()

    def _change_voice(
        self, voice: typing.Optional[str] = None, speaker: typing.Optional[int] = None
    ):
        if voice != self.voice_name:
            if voice:
                # <model>/<voice>
                model_dir = self.model_dir / voice
            else:
                # <model>/
                model_dir = self.model_dir

            if self.model is not None:
                self.model.stop()

            LOG.debug("Changing voice to '%s' (%s)", voice, model_dir)
            self.model = Mimic3(model_dir=model_dir, lang=self.lang)
            self.voice_name = voice

        if self.model is not None:
            self.model.speaker_id = speaker

        self.cache.clear()

    def init(self, bus):
        super().init(bus)

        self.bus.on("mycroft.tts.change-voice", self._handle_change_voice)

    def stop(self):
        self.bus.remove("mycroft.tts.change-voice", self._handle_change_voice)

    def _handle_change_voice(self, message):
        voice = message.data.get("voice")
        speaker = message.data.get("speaker")
        try:
            self._change_voice(voice, speaker=speaker)
        finally:
            self.bus.emit(
                message.reply("mycroft.tts.change-voice.reply", {"voice": voice})
            )

    def get_tts(self, sentence, wav_file):
        """Fetch tts audio using gTTS.

        Arguments:
            sentence (str): Sentence to generate audio for
            wav_file (str): output file path
        Returns:
            Tuple ((str) written file, None)
        """
        assert self.model is not None, "No model loaded"

        # HACK: Mycroft gives "eight a.m.next sentence" sometimes
        sentence = sentence.replace(" a.m.", " a.m. ")
        sentence = sentence.replace(" p.m.", " p.m. ")

        # A I -> A.I.
        sentence = re.sub(
            r"\b([A-Z](?: |$)){2,}",
            lambda m: m.group(0).strip().replace(" ", ".") + ". ",
            sentence,
        )

        # Assume SSML if sentence begins with an angle bracket
        ssml = sentence.strip().startswith("<")

        # HACK: Speak single letters from Mycroft (e.g., "A;")
        if (len(sentence) == 2) and sentence.endswith(";"):
            letter = sentence[0]
            ssml = True
            sentence = f'<say-as interpret-as="spell-out">{letter}</say-as>'
        else:
            # HACK: 'A' -> spell out
            sentence, subs_made = re.subn(
                r"'([A-Z])'", r'<say-as interpret-as="spell-out">\1</say-as>', sentence,
            )
            if subs_made > 0:
                ssml = True

        result = self.model.text_to_speech(text=sentence, ssml=ssml)

        # Write WAV to file
        Path(wav_file).write_bytes(result.wav_bytes)

        phonemes = "|".join(
            " ".join("".join(word_phonemes) for word_phonemes in sent_phonemes)
            for sent_phonemes in result.sentence_phonemes
        )

        return (wav_file, phonemes)

    def _load_existing_audio_files(self):
        """Find the TTS audio files already in the persistent cache."""
        glob_pattern = "*." + self.audio_ext
        for file_path in self.persistent_cache_dir.glob(glob_pattern):
            sentence_hash = file_path.name.split(".")[0]
            audio_file = AudioFile(
                self.persistent_cache_dir, sentence_hash, self.audio_ext
            )
            self.cache.cached_sentences[sentence_hash] = audio_file, None


class Mimic3Validator(TTSValidator):
    """Mycroft TTS validator for Mimic 3"""

    def __init__(self, tts):
        super().__init__(tts)

    def validate_lang(self):
        # TODO: Check against model language
        pass

    def validate_connection(self):
        pass

    def get_tts_class(self):
        return Mimic3TTSPlugin
