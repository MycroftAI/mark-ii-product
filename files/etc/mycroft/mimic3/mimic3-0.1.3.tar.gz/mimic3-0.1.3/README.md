# Mimic 3

A fast, on-device neural text to speech system.


## Installation

``` sh
git clone https://github.com/MycroftAI/mimic3.git
cd mimic3
make install
```

## Running

``` sh
make run
```


## Testing

With server running on port 59125:

``` sh
scripts/marytts.sh localhost:59125/process 'This is a 1st ok test' | aplay
```


## Development

Install development dependencies:

``` sh
pip install -r requirements_dev.txt
```

Reformat code with black:

``` sh
make reformat
```

Check code for style and errors:

``` sh
make check
```

